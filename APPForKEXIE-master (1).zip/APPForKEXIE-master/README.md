#  科协APP制作
A preview version for SAST APP.
项目基本完毕，本项目已开源，需要可下载浏览自取
目前现存问题：
1.APP界面优化很差
2.APP功能较少，虽然混合加密解密，不过除此以外没什么别的功能
3.APP连接延迟大概一秒左右，仍然会出现卡顿

使用的IDE是Android Studio
